package com.example.clientutils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public class Hud {
    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        int y = 4;
        ctx.drawTextWithShadow(mc.textRenderer, "ClientUtils", 4, y, 0xFF55FFFF);
        y += 12;
        for (Module m : ModuleManager.MODULES) {
            if (m.isEnabled()) {
                ctx.drawTextWithShadow(mc.textRenderer, m.name, 4, y, 0xFF55FF55);
                y += 10;
            }
        }
        y += 4;
        String pos = String.format("XYZ: %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
        ctx.drawTextWithShadow(mc.textRenderer, pos, 4, y, 0xFFFFFFFF);
    }
}
