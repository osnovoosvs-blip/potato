package com.example.clientutils;

import com.example.clientutils.modules.*;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();

    public static void init() {
        MODULES.add(new Fly());
        MODULES.add(new Speed());
        MODULES.add(new Esp());
        MODULES.add(new Fullbright());
        MODULES.add(new AutoSprint());
    }

    public static void tick(MinecraftClient mc) {
        for (Module m : MODULES) {
            if (m.isEnabled()) m.onTick(mc);
        }
    }
}
