package com.example.clientutils.modules;

import com.example.clientutils.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerAbilities;

public class Fly extends Module {
    public Fly() { super("Fly"); }

    @Override
    public void onTick(MinecraftClient mc) {
        PlayerAbilities a = mc.player.getAbilities();
        a.allowFlying = true;
        a.flying = true;
        a.setFlySpeed(0.1f);
    }

    @Override
    protected void onDisable(MinecraftClient mc) {
        if (mc.player == null) return;
        PlayerAbilities a = mc.player.getAbilities();
        a.setFlySpeed(0.05f);
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            a.allowFlying = false;
            a.flying = false;
        }
    }
}
