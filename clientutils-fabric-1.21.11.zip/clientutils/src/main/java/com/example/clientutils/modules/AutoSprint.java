package com.example.clientutils.modules;

import com.example.clientutils.Module;
import net.minecraft.client.MinecraftClient;

public class AutoSprint extends Module {
    public AutoSprint() { super("AutoSprint"); }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;
        if (p.forwardSpeed > 0 && !p.horizontalCollision && !p.isSneaking()) {
            p.setSprinting(true);
        }
    }
}
