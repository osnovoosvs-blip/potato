package com.example.clientutils.modules;

import com.example.clientutils.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

public class Esp extends Module {
    public Esp() { super("ESP"); }

    @Override
    public void onTick(MinecraftClient mc) {
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof LivingEntity && e != mc.player) {
                e.setGlowing(true);
            }
        }
    }

    @Override
    protected void onDisable(MinecraftClient mc) {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            e.setGlowing(false);
        }
    }
}
